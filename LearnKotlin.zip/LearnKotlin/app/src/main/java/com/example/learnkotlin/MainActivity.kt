package com.example.learnkotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.learnkotlin.databinding.ActivityMainBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.kakao.sdk.common.KakaoSdk


class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    private lateinit var binding: ActivityMainBinding
    lateinit var googleSignInClient: GoogleSignInClient

    lateinit var imageview: ImageView

    //구글 로그인
    var googleLoginReult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            var data = result.data
            var task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(ApiException::class.java)
            firebaseAuthWithGoogle(account.idToken)
        }

    fun firebaseAuthWithGoogle(idToken: String?) {
        var credential = GoogleAuthProvider.getCredential(idToken, null)

        auth.signInWithCredential((credential)).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                moveMainPage(task.result?.user)
            }
        }
    }

    /**val keyHash = Utility.getKeyHash(this)
    Log.e("Key","keyHash: $keyHash")
    /** KakaoSDK init */
    KakaoSdk.init(this, this.getString(R.string.kakao_app_key))
*/
    override fun onCreate(savedInstanceState: Bundle?) {
        auth = FirebaseAuth.getInstance() //2 FirebaseAuth의 인스턴스 초기화
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        // Kakao SDK 초기화
        KakaoSdk.init(this, "kakao_app_key")

        // 이메일 회원가입
        val joinBtn = findViewById<Button>(R.id.email_login_button)
        joinBtn.setOnClickListener {

            // email, pwd를 받아오기
            //첫번째 방법
            val id: EditText = findViewById<EditText>(R.id.id_edittext)
            val password = findViewById<EditText>(R.id.password_edittext)



            auth!!.createUserWithEmailAndPassword(id.text.toString(), password.text.toString())
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "성공", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "실패", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        //이메일 로그인

        val signBtn = findViewById<Button>(R.id.id_login_button)
        signBtn.setOnClickListener {

        val id: EditText = findViewById<EditText>(R.id.id_edittext)
        val password = findViewById<EditText>(R.id.password_edittext)

        auth!!.signInWithEmailAndPassword(id.text.toString(), password.text.toString())
        .addOnCompleteListener(this) { task ->
        if (task.isSuccessful) {
        Toast.makeText(this, "성공", Toast.LENGTH_SHORT).show()
        } else {
        Toast.makeText(this, "실패", Toast.LENGTH_SHORT).show()
        }
        }

        }






        //구글 로그인 버튼
        binding.googleSignInButton.setOnClickListener {
            signIn() //signin으로 이동
        }

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .requestProfile()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

    }

    //구글 signin 화면으로 이동
    private fun signIn() {
        val i = googleSignInClient.signInIntent
        googleLoginReult.launch(i)
    }

    //로그인 activity에서 Main으로
    fun moveMainPage(user: FirebaseUser?) {
        if (user != null) {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }




}







